module top(input i0, input i1, input i2, output sum, output carry);
wire n0, n1, n2, n3, n4;
assign n0 = n2 & i2;
assign n1 = n2 ^ i2;
assign n2 = i0 ^ i1;
assign n3 = n4 | n0;
assign n4 = i0 & i1;
assign sum = n1;
assign carry = n3;
endmodule
