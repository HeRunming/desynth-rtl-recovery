module top(input i0, input i1, input i2, output sum, output carry);
wire n0, n1, n2, n3, n4;
assign n0 = n3 | n4;
assign n1 = n2 ^ i2;
assign n2 = i0 ^ i1;
assign n3 = i0 & i1;
assign n4 = n2 & i2;
assign sum = n1;
assign carry = n0;
endmodule
