module top(input i0, input i1, input i2, output sum, output carry);
wire n0, n1, n2, n3, n4;
assign n0 = n4 | n2;
assign n1 = i1 ^ i0;
assign n2 = n1 & i2;
assign n3 = n1 ^ i2;
assign n4 = i1 & i0;
assign sum = n3;
assign carry = n0;
endmodule
