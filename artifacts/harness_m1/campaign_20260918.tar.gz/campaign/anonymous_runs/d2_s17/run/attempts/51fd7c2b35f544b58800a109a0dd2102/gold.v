module top(input i0, input i1, input i2, output sum, output carry);
assign sum = i0 ^ i1 ^ i2;
assign carry = (i0 & i1) | (i2 & (i0 ^ i1));
endmodule
