module top(input i0, input i1, input i2, output sum, output carry);
wire n0, n1, n2, n3, n4;
assign n0 = i1 ^ i0;
assign n1 = n2 | n4;
assign n2 = n0 & i2;
assign n3 = n0 ^ i2;
assign n4 = i1 & i0;
assign sum = n3;
assign carry = n1;
endmodule
